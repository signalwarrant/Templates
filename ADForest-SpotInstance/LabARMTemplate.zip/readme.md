# ARM Template: New AD Forest (Single DC, Multiple VMs)

## Prerequisites

* Upload the CreateADPDC.zip file to a file share in Azure.
* Upload the templates in the nestedtemplates folder to a file share in Azure (SVR2012.json, SVR2016.json, SVR2019.json)
* Create a Shared Access Signature to access the file share.
* Create a resource group in Azure.

----------------------------

## Overview

This template will deploy 1 Windows Server 2019 (by Default) Domain controller and set the DNS server on the VNet to the IP of the Domain Controller to facilitate easily adding more VMs. You can create X number of Windows Server 2019 Member Servers, X number of Windows Server 2016 Member Servers, and X number of Windows Server 2012 R2 Member Servers. All of the members server will be added to the same vNET of the DC and added to the Domain.

----------------------

## Deployment Options

### Azure CLI
Open and elevated CMD prompt to access the Azure CLI.
#### Validate the template using the command below.
```
az deployment group validate --resource-group your-RG --template-file c:\templates\ADForest-deploy.json
```
#### Deploy the template using the command below.
```
az deployment group create --name TestLab --resource-group your-RG --template-file c:\templates\ADForest-deploy.json --verbose
```

------------------------------------
### PowerShell
The new(er) Az module is required to run the commands below.
#### Validate the template using the command below.
```
Test-AzResourceGroupDeployment -ResourceGroupName testRG -TemplateFile 'C:\templates\ADForest-deploy.json' -Verbose
```
#### Deploy the template using the command below.
```
New-AzResourceGroupDeployment -Name TestLab -ResourceGroupName your-RG -TemplateFile 'c:\Templates\ADForest-deploy.json'
```
